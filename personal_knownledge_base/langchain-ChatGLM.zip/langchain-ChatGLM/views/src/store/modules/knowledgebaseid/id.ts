import { defineStore } from 'pinia'

export const idStore = defineStore('idStore', {
  state: () => {
    return {
      knowledgeid: 'samples',

    }
  },

})
