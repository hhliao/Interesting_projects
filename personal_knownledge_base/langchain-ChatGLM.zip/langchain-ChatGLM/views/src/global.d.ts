interface Window{
    baseApi: string
}