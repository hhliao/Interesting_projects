#!/bin/bash
python cli.py "$@"
