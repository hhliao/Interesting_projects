# -*- coding : utf-8 -*-
# @Time     : 2023/7/21 - 15:35
# @Author   : rainbowliao
# @FileName : demo_enpei.py
#
import os
from models.loader.args import parser
import models.shared as shared
from models.loader import LoaderCheckPoint
from configs.model_config import LLM_HISTORY_LEN, EMBEDDING_MODEL, EMBEDDING_DEVICE, VECTOR_SEARCH_TOP_K, STREAMING
from chains.local_doc_qa import LocalDocQA

# Show reply with source text from input document
REPLY_WITH_SOURCE = True


def mian():
    llm_model_ins = shared.loaderLLM()
    llm_model_ins.history_len = LLM_HISTORY_LEN

    local_doc_qa = LocalDocQA()
    # 详细的配置文件见 ./config/model_config.py
    local_doc_qa.init_cfg(llm_model=llm_model_ins,             # 初始化的大语言模型，当前为 chatglm2-6b
                          embedding_model=EMBEDDING_MODEL,     # Embedding 模型, 当前为"GanymedeNil/text2vec-large-chinese"
                          embedding_device=EMBEDDING_DEVICE,   # 运行的设备, cuda or cpu
                          top_k=VECTOR_SEARCH_TOP_K)           # 向量检索返回的结果个数，默认top5,

    vs_path = None
    while not vs_path:
        print("注意输入的路径是完整的文件路径，例如knowledge_base/`knowledge_base_id`/content/file.md，多个路径用英文逗号分割")
        filepath = input("Input your local knowledge file path 请输入本地知识文件路径：")
        # './test_data/README.md,./test_data/README_en.md'#

        # 判断 filepath 是否为空，如果为空的话，重新让用户输入,防止用户误触回车
        if not filepath:
            continue

        # 支持加载多个文件
        # filepath = filepath.split(",")
        # filepath错误的返回为None, 如果直接用原先的vs_path,_ = local_doc_qa.init_knowledge_vector_store(filepath)
        # 会直接导致TypeError: cannot unpack non-iterable NoneType object而使得程序直接退出
        # 因此需要先加一层判断，保证程序能继续运行
        # temp, loaded_files = local_doc_qa.init_knowledge_vector_store(filepath)

        # 按照句子切分指定目录下的所有文件
        docs, loaded_files = local_doc_qa.load_and_split_file(filepath)
        print(f'docs = {docs[0]}')
        # 构建或者加载 向量数据库
        temp = local_doc_qa.create_or_add_vector_store(docs)
        if temp is not None:
            vs_path = temp
            print(f"加载的vs_path为: {vs_path}")
        else:
            print("load file failed, re-input your local knowledge file path 请重新输入本地知识文件路径")

    history = []
    while True:
        query = input("Input your question 请输入问题：")
        last_print_len = 0
        for resp, history in local_doc_qa.get_knowledge_based_answer(query=query,
                                                                     vs_path=vs_path,
                                                                     chat_history=history,
                                                                     streaming=STREAMING):
            if STREAMING:
                print(resp["result"][last_print_len:], end="", flush=True)
                last_print_len = len(resp["result"])
            else:
                print(resp["result"])
        if REPLY_WITH_SOURCE:
            source_text = [f"""出处 [{inum + 1}] {os.path.split(doc.metadata['source'])[-1]}：\n\n{doc.page_content}\n\n"""
                           # f"""相关度：{doc.metadata['score']}\n\n"""
                           for inum, doc in
                           enumerate(resp["source_documents"])]
            print("\n\n" + "\n\n".join(source_text))


if __name__ == '__main__':
    args = None
    args = parser.parse_args()
    args_dict = vars(args)

    args_dict['model_name'] = 'chatglm2-6b'
    args_dict['load-in-8bit'] = True
    shared.loaderCheckPoint = LoaderCheckPoint(args_dict)
    mian()
